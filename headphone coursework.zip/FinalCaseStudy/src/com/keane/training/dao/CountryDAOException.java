package com.keane.training.dao;

public class CountryDAOException extends Exception{
	public CountryDAOException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public CountryDAOException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
}
